async function getData(url = '') {
       const response = await fetch(url);
       return await response.json();
}
async function imprimir(){
   let data = await getData('http://localhost:8080/api/v1/product');
   console.log(data);
}

imprimir();
