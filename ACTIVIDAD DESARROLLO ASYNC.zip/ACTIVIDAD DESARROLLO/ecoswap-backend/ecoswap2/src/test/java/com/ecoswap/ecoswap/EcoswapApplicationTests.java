package com.ecoswap.ecoswap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoswapApplicationTests {

	@Test
	void contextLoads() {
	}

}
